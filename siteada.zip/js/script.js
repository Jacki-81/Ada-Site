document.getElementById("botaoEnviar").addEventListener("click", validaFormulario);

function validaFormulario(){//função de validar os campos da página que criamos
  if (document.getElementById("nome").value != "" && document.getElementById("email").value != "" && document.getElementById("telefone").value != "") {
    alert("Prontinho! Você receberá as novidades por email.")
  } else {
    alert("Por favor, preencha os campos nome e email!")
  }
}

